gcc marottosmap.c -o marotto -lm
gcc lyapunov.c -o lyapunov -lm
echo "Executaveis: ./marotto e ./lyapunov"
