gcc lorentz.c -o lorentz -lm
./lorentz
gcc lorentz_h.c -o lorentz_h -lm 
./lorentz_h

